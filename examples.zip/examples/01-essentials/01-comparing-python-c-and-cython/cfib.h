#ifndef __CFIB_H__
#define __CFIB_H__

double cfib(int n);

#endif
