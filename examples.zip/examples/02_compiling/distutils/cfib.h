#ifndef __CFIB_H__
#define __CFIB_H__

unsigned long fib(unsigned long n);

#endif
