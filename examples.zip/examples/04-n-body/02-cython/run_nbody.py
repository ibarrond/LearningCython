import sys
from nbody import main

main(int(sys.argv[1]))
